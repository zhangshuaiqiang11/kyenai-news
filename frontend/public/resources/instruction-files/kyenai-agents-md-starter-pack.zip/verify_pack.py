#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
for item in manifest["files"]:
    path = root / item["path"]
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == item["sha256"], f"checksum mismatch: {item['path']}"
    if item["path"].endswith(".md") and item["path"].startswith("templates/"):
        text = path.read_text(encoding="utf-8")
        assert "## Verification" in text, f"missing Verification section: {item['path']}"
print(f"Verified {len(manifest['files'])} files from KyenAI AGENTS.md Starter Pack v{manifest['version']}.")
