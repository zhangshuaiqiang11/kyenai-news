# KyenAI AGENTS.md Starter Pack

Version: 1.0.0
License: MIT
Canonical guide: https://www.kyenai.com/guides/agents-md-template-for-ai-coding-agents

## Choose a template

- `AGENTS.md`: concise repository-root baseline.
- `AGENTS.node.md`: Node.js package scripts, tests, build, and generated-file rules.
- `AGENTS.python.md`: virtual environment, pytest, formatting, and migration rules.
- `AGENTS.monorepo.md`: root policy plus app/package boundaries and focused verification.

## Example repository structure

```text
repository/
├── AGENTS.md
├── apps/
│   └── web/
│       └── AGENTS.md
└── packages/
    └── shared/
```

Copy one template to the repository root as `AGENTS.md`, replace placeholders, and keep the verification commands runnable. Use nested `AGENTS.md` files only for genuine local exceptions.

Run `python3 verify_pack.py` from the unpacked directory to verify checksums and required sections.
