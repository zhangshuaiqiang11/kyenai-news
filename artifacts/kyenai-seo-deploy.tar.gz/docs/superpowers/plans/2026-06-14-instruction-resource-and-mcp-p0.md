# KyenAI Instruction Resource And MCP P0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a reusable, source-backed instruction-file resource system, deeply improve the AGENTS.md comparison and MCP security guides, add contextual internal links, and prepare a validated GitHub asset package without inventing benchmark data.

**Architecture:** Add focused typed resource modules beside the existing guide catalog, then render them through reusable React components attached only to selected guides. Generate static downloads and the GitHub-ready package from the same records so website content, templates, exports, and future projects cannot drift independently.

**Tech Stack:** Next.js 13 Pages Router, React 18, TypeScript, Vitest, Testing Library, Node.js generation scripts, static public downloads, FastAPI/Pytest, Docker Compose, Caddy.

---

## File Map

### New Resource Modules

- Create `frontend/lib/instruction-resources.ts`: typed compatibility, scope, Cursor migration, template, repository-tree, and benchmark records.
- Create `frontend/lib/mcp-security-resource.ts`: typed MCP threat, permission, authentication, logging, and review records.
- Create `frontend/lib/resource-exports.ts`: deterministic Markdown, JSON, and CSV export helpers.

### New Components

- Create `frontend/components/InstructionCompatibilityMatrix.tsx`: accessible tool/file support matrix.
- Create `frontend/components/InstructionScopeGuide.tsx`: priority, scope, nesting, and Cursor migration sections.
- Create `frontend/components/RepositoryTree.tsx`: semantic example repository tree.
- Create `frontend/components/TemplateDownloads.tsx`: copyable template previews and download links.
- Create `frontend/components/BenchmarkPanel.tsx`: benchmark protocol and measured-only results.
- Create `frontend/components/McpSecurityControls.tsx`: permissions, authentication, logging, and review controls.

### New Static Assets And GitHub Package

- Create `scripts/generate-instruction-resources.mjs`: generate public downloads and the GitHub-ready package.
- Create `frontend/public/resources/instruction-files/compatibility.json`.
- Create `frontend/public/resources/instruction-files/compatibility.csv`.
- Create `frontend/public/resources/instruction-files/AGENTS.md`.
- Create `frontend/public/resources/instruction-files/CLAUDE.md`.
- Create `frontend/public/resources/instruction-files/copilot-instructions.md`.
- Create `frontend/public/resources/instruction-files/cursor-project-rule.mdc`.
- Create `frontend/public/resources/mcp-security-review.md`.
- Create `artifacts/kyenai-agent-instruction-files/README.md` and the package tree defined by the approved specification.

### Existing Files To Modify

- Modify `frontend/lib/types.ts`: attach optional structured resource IDs to guides.
- Modify `frontend/lib/guides.ts`: deeply update the AGENTS.md comparison and MCP security records.
- Modify `frontend/lib/guide-expansion.ts`: strengthen adjacent-guide internal links and benchmark wording.
- Modify `frontend/lib/guide-editorial.ts`: align target queries with observed GSC language.
- Modify `frontend/pages/guides/[slug].tsx`: render structured resource components.
- Modify `frontend/pages/index.tsx`: add contextual featured resource links.
- Modify `frontend/pages/guides/index.tsx`: add focused comparison and security paths.
- Modify `frontend/styles/globals.css`: style the new tables, code previews, tree, downloads, and benchmark states.
- Modify `package.json`: add resource generation and audit scripts.
- Modify `frontend/package.json` only if a script must run from the frontend package.

### Tests

- Create `frontend/tests/instruction-resources.test.ts`.
- Create `frontend/tests/resource-exports.test.ts`.
- Create `frontend/tests/instruction-resource-components.test.tsx`.
- Create `frontend/tests/mcp-security-resource.test.tsx`.
- Modify `frontend/tests/guides.test.ts`.
- Modify `frontend/tests/public-seo-copy.test.tsx`.
- Modify `frontend/tests/sitemap.test.ts` only if resource links affect sitemap assumptions; static downloads must not be added as indexable pages.

Because `/Users/kyen/Documents/SEO` is not a Git repository, each commit step below becomes a changed-file checkpoint.

## Task 1: Add Typed Instruction Resource Records

**Files:**
- Create: `frontend/lib/instruction-resources.ts`
- Modify: `frontend/lib/types.ts`
- Test: `frontend/tests/instruction-resources.test.ts`

- [ ] **Step 1: Write the failing type and evidence tests**

Create tests requiring:

```ts
import {
  benchmarkProtocol,
  instructionTemplates,
  repositoryTree,
  toolInstructionSupport,
} from "../lib/instruction-resources";

it("requires evidence for every documented support claim", () => {
  for (const record of toolInstructionSupport) {
    if (record.status === "documented" || record.status === "legacy") {
      expect(record.sourceUrl).toMatch(/^https:\/\//);
      expect(record.publisher.length).toBeGreaterThan(0);
      expect(record.verifiedAt).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    }
  }
});

it("answers Copilot CLAUDE.md support without ambiguity", () => {
  const records = toolInstructionSupport.filter(
    (item) => item.toolId === "github-copilot" && item.path === "CLAUDE.md",
  );

  expect(records.some((item) => item.status === "documented")).toBe(true);
  expect(records.some((item) => item.status === "unsupported")).toBe(true);
  expect(
    records.every((item) =>
      item.recommendation.includes(".github/copilot-instructions.md"),
    ),
  ).toBe(true);
});

it("ships four stable templates and a public example tree", () => {
  expect(instructionTemplates.map((item) => item.downloadName)).toEqual([
    "AGENTS.md",
    "CLAUDE.md",
    "copilot-instructions.md",
    "cursor-project-rule.mdc",
  ]);
  expect(repositoryTree).toContain("example-repository/");
  expect(repositoryTree).toContain(".cursor/");
});

it("never fills benchmark metrics with estimates", () => {
  for (const run of benchmarkProtocol.runs) {
    expect(run.metricSource).not.toBe("estimated");
    if (run.status === "not-measured") {
      expect(run.elapsedSeconds).toBeNull();
      expect(run.measuredCostUsd).toBeNull();
      expect(run.humanInterventions).toBeNull();
    }
  }
});
```

- [ ] **Step 2: Run the test and verify the expected import failure**

Run:

```bash
PATH=/Users/kyen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH \
  npm test --prefix frontend -- tests/instruction-resources.test.ts
```

Expected: FAIL because `frontend/lib/instruction-resources.ts` does not exist.

- [ ] **Step 3: Add resource types**

Add to `frontend/lib/types.ts`:

```ts
export type SupportStatus = "documented" | "legacy" | "observed" | "unsupported" | "unknown";

export type ToolInstructionSupport = {
  id: string;
  toolId: "openai-codex" | "claude-code" | "github-copilot" | "cursor";
  toolName: string;
  path: string;
  status: SupportStatus;
  scopes: Array<"repository" | "nested-directory" | "path-specific" | "organization" | "user">;
  priority: string;
  nesting: string;
  recommendation: string;
  sourceUrl?: string;
  publisher?: string;
  verifiedAt: string;
};

export type InstructionTemplate = {
  id: string;
  title: string;
  targetPath: string;
  downloadName: string;
  purpose: string;
  applicableToolIds: ToolInstructionSupport["toolId"][];
  body: string;
  cautions: string[];
};

export type BenchmarkRun = {
  id: string;
  toolId: ToolInstructionSupport["toolId"];
  toolVersion: string | null;
  status: "not-measured" | "completed" | "failed";
  metricSource: "measured" | "unavailable";
  elapsedSeconds: number | null;
  measuredCostUsd: number | null;
  humanInterventions: number | null;
  filesChanged: number | null;
  verificationPassed: boolean | null;
  evidenceUrl: string | null;
  limitations: string[];
};

export type GuideResourceId = "instruction-files" | "mcp-security";
```

Add `resourceIds?: GuideResourceId[]` to `Guide`.

- [ ] **Step 4: Create the instruction resource module**

Define:

```ts
export const instructionResourceVerifiedAt = "2026-06-14";

export const toolInstructionSupport: ToolInstructionSupport[] = [
  // One sourced record for each supported current/legacy path. Model
  // surface-dependent support explicitly rather than collapsing it into a
  // global yes/no answer.
];

export const instructionTemplates: InstructionTemplate[] = [
  // Four approved templates with complete Markdown bodies.
];

export const repositoryTree = `example-repository/
├── AGENTS.md
├── CLAUDE.md
├── .github/
│   └── copilot-instructions.md
├── .cursor/
│   └── rules/
│       └── project-guidance.mdc
├── apps/
│   └── web/
│       └── AGENTS.md
└── packages/
    └── api/`;
```

Before finalizing support records, verify current behavior against official OpenAI, Anthropic, GitHub, and Cursor documentation. Mark undocumented behavior `unknown` rather than inferring it.

- [ ] **Step 5: Define the measured-only benchmark protocol**

Use a contained public task:

```ts
export const benchmarkProtocol = {
  repository: "KyenAI public instruction example repository",
  revision: null,
  taskId: "instruction-drift-fix-001",
  task:
    "Correct one stale test command in repository instructions and make all tool-specific files consistent without changing application code.",
  successCriteria: [
    "All instruction files name the same test command.",
    "The repository verification command passes.",
    "No application source file changes.",
  ],
  verificationCommand: "node scripts/verify-instructions.mjs",
  runs: [
    notMeasuredRun("openai-codex"),
    notMeasuredRun("claude-code"),
  ],
};
```

`notMeasuredRun` must set every numeric metric to `null`.

- [ ] **Step 6: Run focused tests**

Expected: all instruction resource tests PASS.

- [ ] **Step 7: Record checkpoint**

Record the changed files and test output in the implementation log; do not claim tool behavior not supported by the cited official sources.

## Task 2: Generate Downloads And GitHub-Ready Assets

**Files:**
- Create: `frontend/lib/resource-exports.ts`
- Create: `scripts/generate-instruction-resources.mjs`
- Create: `frontend/tests/resource-exports.test.ts`
- Modify: `package.json`

- [ ] **Step 1: Write failing export tests**

Require:

```ts
expect(renderCompatibilityJson()).toEqual(
  JSON.stringify(toolInstructionSupport, null, 2) + "\n",
);
expect(renderCompatibilityCsv()).toContain(
  "tool,path,status,scopes,priority,nesting,recommendation,source_url,publisher,verified_at",
);
expect(renderTemplateFile("agents-md")).toBe(
  instructionTemplates.find((item) => item.id === "agents-md")!.body.trim() + "\n",
);
```

Also parse the CSV with a real CSV parser or a focused round-trip helper; do not validate it through comma splitting.

- [ ] **Step 2: Run and verify failure**

Expected: FAIL because export helpers do not exist.

- [ ] **Step 3: Implement deterministic renderers**

Create:

```ts
export function renderCompatibilityJson(): string;
export function renderCompatibilityCsv(): string;
export function renderTemplateFile(templateId: string): string;
export function renderGithubReadme(): string;
export function renderBenchmarkResultsJson(): string;
```

CSV rendering must quote fields containing commas, quotes, or newlines and double embedded quotes.

- [ ] **Step 4: Add the generation script**

The script must:

1. import or load the compiled resource records;
2. create `frontend/public/resources/instruction-files/`;
3. write four templates plus JSON and CSV;
4. write `frontend/public/resources/mcp-security-review.md`;
5. recreate `artifacts/kyenai-agent-instruction-files/` without touching unrelated artifacts;
6. write the approved package tree;
7. verify every generated file is non-empty.

Use Node `fs/promises`, `path`, and structured render helpers. Do not assemble JSON manually.

- [ ] **Step 5: Add scripts**

Add to root `package.json`:

```json
"generate:resources": "bash scripts/run-node-script.sh scripts/generate-instruction-resources.mjs",
"audit:resources": "bash scripts/run-node-script.sh --test scripts/resource-generation.test.mjs"
```

- [ ] **Step 6: Run generation and tests**

Run `npm run generate:resources`, then focused export tests. Expected: generated files exist and tests PASS.

- [ ] **Step 7: Record checkpoint**

List every generated path and confirm no `.env`, secret, OAuth, or production credential file appears under the package.

## Task 3: Build Reusable Instruction Components

**Files:**
- Create: the five instruction components listed in the file map
- Create: `frontend/tests/instruction-resource-components.test.tsx`
- Modify: `frontend/styles/globals.css`

- [ ] **Step 1: Write failing rendered-component tests**

Test that:

- the matrix contains Codex, Claude Code, GitHub Copilot, and Cursor;
- the direct Copilot answer explains that `CLAUDE.md` support depends on the
  Copilot surface and recommends `.github/copilot-instructions.md` for the
  broadest repository-wide compatibility;
- current and legacy Cursor formats are labeled distinctly;
- all four download links point to `/resources/instruction-files/...`;
- the tree is visible as text, not an image-only artifact;
- unmeasured benchmark cells render `Not measured`;
- no `$0`, `0 seconds`, or `0 interventions` placeholder is rendered.

- [ ] **Step 2: Run and verify missing-component failures**

- [ ] **Step 3: Implement accessible components**

Use semantic headings, `<table>`, `<pre><code>`, `<a download>`, and `<dl>` where appropriate. Keep copying optional and progressive; server-rendered template text and download links must work without client JavaScript.

- [ ] **Step 4: Add restrained styles**

Follow existing tokens:

- white background;
- teal for sourced/current states;
- amber for legacy/caution states;
- muted gray for unknown and `Not measured`;
- no new card-heavy redesign;
- horizontal table scroll on mobile.

- [ ] **Step 5: Run component tests**

Expected: PASS.

- [ ] **Step 6: Record checkpoint**

Capture rendered test assertions and confirm the components expose no private editorial scores.

## Task 4: Deeply Update The AGENTS.md Comparison Guide

**Files:**
- Modify: `frontend/lib/guides.ts`
- Modify: `frontend/pages/guides/[slug].tsx`
- Modify: `frontend/tests/guides.test.ts`
- Modify: `frontend/tests/public-seo-copy.test.tsx`

- [ ] **Step 1: Write failing guide-content expectations**

Require the guide to:

- attach `resourceIds: ["instruction-files"]`;
- include natural sections for compatibility, canonical policy, migration, and testing;
- use the updated title and description;
- link to the AGENTS.md template, Codex vs Claude Code, Claude hooks/MCP, and MCP security guides.

- [ ] **Step 2: Add failing page-render tests**

Render the guide and assert:

```ts
expect(screen.getByText(/does not read CLAUDE\.md/i)).toBeTruthy();
expect(screen.getByRole("heading", { name: /tool compatibility matrix/i })).toBeTruthy();
expect(screen.getByRole("heading", { name: /file priority and scope/i })).toBeTruthy();
expect(screen.getByRole("heading", { name: /cursor legacy and current rules/i })).toBeTruthy();
expect(screen.getByRole("heading", { name: /same-repository benchmark/i })).toBeTruthy();
```

- [ ] **Step 3: Run and verify failures**

- [ ] **Step 4: Update the guide record**

Change the summary, intent, keyword variants, detailed prose, recommended play, decision table, action steps, pitfalls, checklist, evidence, and `updatedAt`.

Use evidence-backed language. Do not claim that a tool reads a file unless the resource record supports it.

- [ ] **Step 5: Render resources conditionally**

In the guide page:

```tsx
const hasInstructionResources = guide.resourceIds?.includes("instruction-files");
...
{hasInstructionResources ? <InstructionResourceSections /> : null}
```

Place it after the answer panel and before generic execution steps so the primary answers appear early.

- [ ] **Step 6: Run focused guide tests**

Expected: PASS.

- [ ] **Step 7: Record checkpoint**

Check the SSR-oriented component output contains all approved sections and the canonical path is unchanged.

## Task 5: Restructure The MCP Security Resource

**Files:**
- Create: `frontend/lib/mcp-security-resource.ts`
- Create: `frontend/components/McpSecurityControls.tsx`
- Modify: `frontend/lib/guides.ts`
- Modify: `frontend/pages/guides/[slug].tsx`
- Create: `frontend/tests/mcp-security-resource.test.tsx`
- Modify: `frontend/lib/guide-editorial.ts`

- [ ] **Step 1: Write failing MCP resource tests**

Require threat records for:

- prompt injection;
- excessive permissions;
- secret exposure;
- unsafe writes/deletes;
- network reach;
- third-party supply chain.

Require control records for:

- authentication;
- least privilege;
- secret storage and rotation;
- read/write separation;
- human approval;
- audit logs;
- isolation;
- revocation and incident response.

- [ ] **Step 2: Verify failure**

- [ ] **Step 3: Implement typed MCP records**

Each permission row must cover:

```ts
{
  capability: "Read repository files",
  default: "allow-scoped",
  dataRisk: "internal",
  approval: "not required for approved paths",
  logging: "actor, session, tool, target, outcome",
  launchGate: "path allowlist documented",
}
```

Add distinct rows for write, delete, network, secrets, and production access.

- [ ] **Step 4: Update guide metadata and query watchlist**

Primary keyword: `MCP security checklist`.

Watch queries must include:

- `mcp security`;
- `mcp server security`;
- `how to secure an mcp server`;
- `mcp authentication`;
- `mcp permissions`;
- `ai agent tool security`.

- [ ] **Step 5: Render the MCP component**

Attach `resourceIds: ["mcp-security"]` and render after the quick answer.

- [ ] **Step 6: Generate and link the review template**

The Markdown template must include server owner, data classes, methods, credentials, network reach, approval gates, logging, dependency review, revocation, and sign-off.

- [ ] **Step 7: Run focused tests**

Expected: PASS.

## Task 6: Add Contextual Internal Links

**Files:**
- Modify: `frontend/pages/index.tsx`
- Modify: `frontend/pages/guides/index.tsx`
- Modify: `frontend/lib/guides.ts`
- Modify: `frontend/lib/guide-expansion.ts`
- Create or modify: `frontend/tests/internal-links.test.tsx`

- [ ] **Step 1: Write failing link-placement tests**

Require at least:

- two homepage links to the comparison and MCP security guides;
- two Guides-index links to the same resources;
- comparison/template reciprocal links;
- Codex-vs-Claude to comparison;
- hooks/MCP to comparison;
- governance to MCP security;
- local-vs-cloud to MCP security.

Test actual href and surrounding reader-facing text.

- [ ] **Step 2: Run and verify failures**

- [ ] **Step 3: Add homepage resource copy**

Add one focused “Instruction files” item and one “MCP security” item inside the existing playbook section. Do not create a new giant marketing section.

- [ ] **Step 4: Add Guide-index paths**

Add a compact featured-path block above the grid with plain explanatory copy.

- [ ] **Step 5: Strengthen guide relationships**

Use varied anchors and accurate reasons. Avoid repeating an exact keyword in every link.

- [ ] **Step 6: Run link tests**

Expected: PASS and at least eight approved contextual placements.

## Task 7: Protect SEO, Exports, And Public Copy

**Files:**
- Modify: `frontend/tests/seo.test.ts`
- Modify: `frontend/tests/public-seo-copy.test.tsx`
- Modify: `frontend/tests/sitemap.test.ts`
- Modify: `frontend/lib/seo.ts` only if resource metadata or JSON-LD needs adjustment

- [ ] **Step 1: Add regression assertions**

Prove:

- canonical URLs remain unchanged;
- resource downloads are not added to the XML sitemap;
- TechArticle citations contain current official sources;
- visible benchmark status and JSON output agree;
- FAQ schema does not invent benchmark claims;
- internal editorial fields remain absent.

- [ ] **Step 2: Run focused SEO tests**

- [ ] **Step 3: Implement only necessary SEO helper changes**

Do not add schema types that do not match visible content. Keep template downloads as ordinary linked resources.

- [ ] **Step 4: Re-run focused tests**

Expected: PASS.

## Task 8: Run Full Quality Gates

**Files:** all changed files.

- [ ] **Step 1: Generate resources from a clean output directory**

Remove only generated resource outputs through the generation script's scoped cleanup, then regenerate them.

- [ ] **Step 2: Run brand spelling audit**

```bash
python3 /Users/kyen/.codex/skills/kyenai-seo-autopilot/scripts/audit_terms.py \
  --root /Users/kyen/Documents/SEO
```

Expected: no high-confidence issues.

- [ ] **Step 3: Run frontend tests**

```bash
PATH=/Users/kyen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH \
  npm run test:web
```

Expected: zero failures.

- [ ] **Step 4: Run backend tests**

```bash
python3 -m pytest backend/tests -q
```

Expected: zero failures.

- [ ] **Step 5: Run production build**

```bash
PATH=/Users/kyen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:$PATH \
  npm run build
```

Expected: exit 0.

- [ ] **Step 6: Audit generated package for secrets**

Search filenames and contents for common credential markers while excluding known examples. Expected: no secrets.

- [ ] **Step 7: Record checkpoint**

Record exact test counts, build result, generated file count, and spelling/secret audit output.

## Task 9: Browser And Responsive Verification

**Files:** no code unless QA exposes defects.

- [ ] **Step 1: Start the local production-like app**

Use the repo's existing local startup process and known API fallback behavior.

- [ ] **Step 2: Verify desktop**

Open:

- `/`;
- `/guides`;
- `/guides/agents-md-vs-claude-md-cursorrules-copilot-instructions`;
- `/guides/agents-md-template-for-ai-coding-agents`;
- `/guides/secure-mcp-servers-ai-coding-agents`.

Check headings, tables, direct answer, downloads, evidence, internal links, and benchmark states.

- [ ] **Step 3: Verify mobile**

Check that matrices scroll without clipping, code previews wrap or scroll safely, downloads remain usable, and no main content overflows.

- [ ] **Step 4: Verify download responses**

Open every generated public asset and confirm a 200 response and expected text.

- [ ] **Step 5: Fix any visible defects and rerun affected tests**

- [ ] **Step 6: Capture QA evidence**

Save desktop and mobile screenshots under `artifacts/` only when useful; do not add them to the sitemap.

## Task 10: Deploy And Verify Production

**Files:**
- Use existing deployment files without changing secrets.

- [ ] **Step 1: Review the changed-file inventory**

Confirm no user files were overwritten and no secret file is included.

- [ ] **Step 2: Deploy with the established KyenAI production workflow**

Use the deployment procedure in the KyenAI SEO skill. Stop on any failed test, build, transfer, container, or health check.

- [ ] **Step 3: Verify production URLs and SSR**

Confirm HTTP 200, title, description, canonical, H1, direct answer, matrices, downloads, citations, and JSON-LD.

- [ ] **Step 4: Verify robots and sitemap**

Confirm sitemap URL count does not unexpectedly expand and static resources are not listed as pages.

- [ ] **Step 5: Record deployment baseline**

Record deployment date and affected URLs for a 7–14 day GSC comparison.

## Task 11: Publish The GitHub Asset

**Files:**
- Source: `artifacts/kyenai-agent-instruction-files/`
- External target: a new or explicitly selected public GitHub repository.

- [ ] **Step 1: Validate the local package**

Confirm README, license, templates, data, example tree, protocol, and measured-only results are complete.

- [ ] **Step 2: Identify the GitHub account and repository target**

Use the connected GitHub app. Do not guess the owner or silently create a repository.

- [ ] **Step 3: Request action-time confirmation**

Creating or publishing a public repository is an external write action. Present the exact owner, repository name, visibility, and files before proceeding.

- [ ] **Step 4: Publish after confirmation**

Create or update the repository using the connected GitHub workflow.

- [ ] **Step 5: Verify the public repository**

Check file visibility, Markdown rendering, downloads, license, no secrets, and the backlink to the KyenAI guide.

- [ ] **Step 6: Add the verified GitHub URL to KyenAI**

Only after the repository exists, add its URL to the resource record, regenerate assets, rerun focused tests/build, deploy, and verify the production link.

## Task 12: Completion Audit

- [ ] **Step 1: Re-read the approved design**

Check every explicit requirement against current files, generated assets, tests, production pages, and GitHub state.

- [ ] **Step 2: Build a requirement evidence table**

Mark each item complete, incomplete, contradicted, or unverified. Treat indirect evidence as unverified.

- [ ] **Step 3: Resolve all incomplete requirements**

Do not mark the goal complete while the GitHub package, production deployment, or required verification remains outstanding.

- [ ] **Step 4: Run final fresh verification**

Repeat generation, tests, build, audits, and key production checks.

- [ ] **Step 5: Report results**

Summarize P0 diagnosis, code/content changes, generated assets, links, test/build counts, deployment, GitHub repository, and the 7–14 day GSC observation plan.
