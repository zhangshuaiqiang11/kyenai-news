# KyenAI Existing-Page SEO Optimization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve the public search presentation, click expectation, trust signals, internal linking, and AI-answer extractability of KyenAI's existing pages without adding or renaming indexable URLs.

**Architecture:** Keep private opportunity fields in the existing `Guide` model, but remove them from public React output. Centralize natural FAQ wording in `frontend/lib/seo.ts`, derive the global freshness label from real guide/article dates in a focused helper, and protect all behavior with rendered-page and SEO-helper tests before deployment.

**Tech Stack:** Next.js 13 Pages Router, React 18, TypeScript, Vitest, Testing Library, FastAPI/Pytest, Docker Compose, Caddy.

---

## File Map

- Create `frontend/lib/freshness.ts`: calculate the latest truthful editorial update from existing content dates.
- Create `frontend/tests/public-seo-copy.test.tsx`: rendered-page regression tests for internal-field removal, one quick answer, and reader-facing guide copy.
- Modify `frontend/components/Layout.tsx`: render a derived update date instead of a hard-coded timestamp.
- Modify `frontend/pages/guides/[slug].tsx`: hide internal planning fields, avoid duplicate quick answers, and use reader-facing related-content language.
- Modify `frontend/pages/guides/index.tsx`: replace internal scores and priority labels with task/audience copy.
- Modify `frontend/pages/index.tsx`: remove unsupported demand-validation wording and improve the homepage snippet promise.
- Modify `frontend/lib/seo.ts`: generate natural guide/article FAQ wording while keeping visible FAQ content and JSON-LD aligned.
- Modify `frontend/tests/layout.test.tsx`: prove the status date comes from real content.
- Modify `frontend/tests/guides.test.ts`: prove natural FAQs and snippet metadata quality.
- Modify `frontend/tests/seo.test.ts`: update article FAQ expectations and protect natural wording.
- Modify `frontend/styles/globals.css` only if the changed guide metadata layout needs a small responsive adjustment.

Because `/Users/kyen/Documents/SEO` is not a Git repository, commit steps are replaced with explicit changed-file and test checkpoints.

### Task 1: Protect Public Guide Copy With Failing Render Tests

**Files:**
- Create: `frontend/tests/public-seo-copy.test.tsx`
- Test: `frontend/tests/public-seo-copy.test.tsx`

- [ ] **Step 1: Write the failing guide-detail test**

Create a jsdom test that renders the existing guide page with one real guide and no related articles:

```tsx
/** @vitest-environment jsdom */
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import GuidePage from "../pages/guides/[slug]";
import { getGuide, getInternalLinkedGuides } from "../lib/guides";

(globalThis as typeof globalThis & { React: typeof React }).React = React;
afterEach(cleanup);

describe("public SEO copy", () => {
  it("keeps editorial scoring fields out of the public guide and renders one quick answer", () => {
    const guide = getGuide("codex-vs-claude-code")!;

    render(
      <GuidePage
        guide={guide}
        relatedGuides={getInternalLinkedGuides(guide)}
        relatedArticles={[]}
      />,
    );

    expect(screen.queryByText("Primary keyword")).toBeNull();
    expect(screen.queryByText("Demand")).toBeNull();
    expect(screen.queryByText("Attackability")).toBeNull();
    expect(screen.queryByText("KyenAI fit")).toBeNull();
    expect(screen.queryByText("GSC query watchlist")).toBeNull();
    expect(screen.queryByText("P0")).toBeNull();
    expect(screen.getAllByRole("heading", { name: "Quick Answer" })).toHaveLength(1);
  });
});
```

- [ ] **Step 2: Add a failing guide-index test**

Extend the same file:

```tsx
import GuidesPage from "../pages/guides";
import { getGuides } from "../lib/guides";

it("presents guide cards for readers instead of exposing editorial scores", () => {
  render(<GuidesPage guides={getGuides().slice(0, 2)} />);

  expect(screen.queryByText("Attackability")).toBeNull();
  expect(screen.queryByText("Fit")).toBeNull();
  expect(screen.queryByText("P0")).toBeNull();
  expect(screen.getAllByText(/Who it helps/i).length).toBeGreaterThan(0);
});
```

- [ ] **Step 3: Run the new tests and verify the expected failures**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/public-seo-copy.test.tsx
```

Expected: FAIL because the current pages expose `Primary keyword`, scoring labels, `P0`, the watchlist, and duplicate quick-answer headings.

- [ ] **Step 4: Record the red checkpoint**

Record the exact failing assertions and confirm no failure is caused by an import or jsdom setup error.

### Task 2: Remove Internal Editorial Fields From Public Pages

**Files:**
- Modify: `frontend/pages/guides/[slug].tsx`
- Modify: `frontend/pages/guides/index.tsx`
- Modify: `frontend/pages/index.tsx`
- Modify: `frontend/styles/globals.css` if needed
- Test: `frontend/tests/public-seo-copy.test.tsx`

- [ ] **Step 1: Make the guide header reader-facing**

In `frontend/pages/guides/[slug].tsx`:

- remove the visible priority label;
- replace `Intent` and `Primary keyword` with `Best for` and `Use this guide to`;
- keep the real updated date;
- remove the demand/attackability/fit definition list from the answer panel.

The resulting visible values should use:

```tsx
<div className="guide-meta-row">
  <span>{guide.pageType}</span>
  <span>Updated {formatDate(guide.updatedAt)}</span>
</div>
<dl>
  <div>
    <dt>Best for</dt>
    <dd>{guide.audience}</dd>
  </div>
  <div>
    <dt>Use this guide to</dt>
    <dd>{guide.intent}</dd>
  </div>
</dl>
```

- [ ] **Step 2: Render the quick answer once**

Create the content section list without the first quick-answer section:

```tsx
const contentSections = guide.sections.filter(
  (section) => section.heading.toLowerCase() !== "quick answer",
);
```

Render `contentSections` in the article body while retaining the answer panel as the only visible `Quick Answer`.

- [ ] **Step 3: Remove the public watchlist and internal cluster language**

Delete the `GSC query watchlist` aside section. Keep secondary topics only when presented as `Related topics`.

Change:

```tsx
<p>Internal links for the next step in this SEO cluster.</p>
```

to:

```tsx
<p>Continue with the setup, security, or workflow decision that follows this guide.</p>
```

- [ ] **Step 4: Replace guide-index scoring with reader utility**

In `frontend/pages/guides/index.tsx`:

- remove `priority`, demand, attackability, and fit output;
- retain `pageType`;
- display `Who it helps` followed by `guide.audience`;
- change the intro to source-backed, task-oriented language without claiming demand validation.

Use:

```tsx
<div className="guide-card-meta">
  <span>{guide.pageType}</span>
</div>
...
<p className="guide-card-audience">
  <strong>Who it helps:</strong> {guide.audience}
</p>
```

- [ ] **Step 5: Replace homepage production language**

In `frontend/pages/index.tsx`:

- replace `Search-demand-tested guides` with `Source-backed guides`;
- replace `Validated demand pages` with `Practical playbooks`;
- replace scoring language with a description of tasks readers can complete;
- improve the homepage description to promise concrete comparisons, setup guidance, and security checks already present on the page.

Use this metadata description:

```ts
"Compare Codex, Claude Code, Copilot, Cursor, and other AI coding agents with source-backed setup, security, migration, and workflow guides."
```

- [ ] **Step 6: Run the focused render tests**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/public-seo-copy.test.tsx
```

Expected: PASS.

- [ ] **Step 7: Check changed public templates**

Run:

```bash
rg -n "Primary keyword|GSC query watchlist|Attackability|KyenAI fit|Validated demand pages|search-demand-tested|SEO cluster" \
  frontend/pages frontend/components
```

Expected: no public-template matches.

### Task 3: Replace Template-Like FAQs With Natural Questions

**Files:**
- Modify: `frontend/tests/guides.test.ts`
- Modify: `frontend/tests/seo.test.ts`
- Modify: `frontend/lib/seo.ts`

- [ ] **Step 1: Write failing guide FAQ expectations**

Update the guide FAQ test to require:

```ts
expect(faqs.map((faq) => faq.question)).toEqual([
  "What should you do first?",
  "Who is this guide for?",
  "What evidence supports this guide?",
]);
expect(faqs[0].answer).toBe(guide!.recommendedPlay[0]);
expect(faqs[1].answer).toBe(guide!.audience);
expect(faqs[2].answer).toContain(guide!.evidence[0].publisher);
expect(faqs.some((faq) => faq.question.includes(guide!.primaryKeyword))).toBe(false);
```

- [ ] **Step 2: Write failing article FAQ expectations**

In `frontend/tests/seo.test.ts`, require:

```ts
expect(faqs.map((faq) => faq.question)).toEqual([
  "What changed in this update?",
  `Why does this matter for ${article.category.toLowerCase()} teams?`,
  "What sources support this article?",
]);
expect(jsonLd.mainEntity[0].acceptedAnswer.text).toBe(article.summary);
```

- [ ] **Step 3: Run the focused tests and verify they fail**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/guides.test.ts tests/seo.test.ts
```

Expected: FAIL because the existing functions create keyword-filled, mechanical questions.

- [ ] **Step 4: Implement natural FAQ builders**

In `frontend/lib/seo.ts`, implement:

```ts
export function buildGuideFaqs(guide: Guide): FaqItem[] {
  return [
    {
      question: "What should you do first?",
      answer: guide.recommendedPlay[0],
    },
    {
      question: "Who is this guide for?",
      answer: guide.audience,
    },
    {
      question: "What evidence supports this guide?",
      answer: `This guide uses official or high-confidence material from ${guide.evidence
        .map((source) => source.publisher)
        .join(", ")}. The source links and scope notes are listed on the page.`,
    },
  ];
}

export function buildArticleFaqs(article: Article): FaqItem[] {
  const contextParagraph =
    article.blocks.find((block) => block.type === "paragraph" && block.content !== article.summary)?.content ||
    article.summary;
  const sourceNames = article.sources.map((source) => source.publisher).join(", ");

  return [
    {
      question: "What changed in this update?",
      answer: article.summary,
    },
    {
      question: `Why does this matter for ${article.category.toLowerCase()} teams?`,
      answer: contextParagraph,
    },
    {
      question: "What sources support this article?",
      answer: sourceNames
        ? `The article uses source records from ${sourceNames}; links and publication dates appear in the Sources section.`
        : "Supporting links and publication dates appear in the Sources section.",
    },
  ];
}
```

- [ ] **Step 5: Run focused FAQ tests**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/guides.test.ts tests/seo.test.ts
```

Expected: PASS.

### Task 4: Derive The Global Freshness Label From Real Content

**Files:**
- Create: `frontend/lib/freshness.ts`
- Modify: `frontend/components/Layout.tsx`
- Modify: `frontend/tests/layout.test.tsx`

- [ ] **Step 1: Write the failing freshness test**

Add to `frontend/tests/layout.test.tsx`:

```tsx
it("shows the newest real content date instead of a hard-coded status time", () => {
  render(
    <Layout>
      <p>Public page</p>
    </Layout>,
  );

  expect(screen.getByText("Content updated Jun 6, 2026")).toBeTruthy();
  expect(screen.queryByText(/Jun 3, 2026 08:54 UTC/)).toBeNull();
});
```

- [ ] **Step 2: Run the layout test and verify it fails**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/layout.test.tsx
```

Expected: FAIL because the layout still renders the hard-coded timestamp instead of the newest real content date.

- [ ] **Step 3: Implement the focused freshness helper**

Create `frontend/lib/freshness.ts`:

```ts
import { getGuides } from "./guides";
import { seedArticles } from "./seed";

export function getLatestEditorialUpdate(): string {
  const timestamps = [
    ...seedArticles
      .filter((article) => article.status === "published")
      .map((article) => article.updatedAt),
    ...getGuides().map((guide) => guide.updatedAt),
  ]
    .map((value) => new Date(value).getTime())
    .filter(Number.isFinite);

  return new Date(Math.max(...timestamps)).toISOString();
}
```

- [ ] **Step 4: Use the derived value in Layout**

In `frontend/components/Layout.tsx`, import `getLatestEditorialUpdate` and `formatDate`, then render:

```tsx
<span>Content updated {formatDate(getLatestEditorialUpdate())}</span>
```

Keep the other trust labels factual and change `Self-optimizing guardrails on` to `Editorial guardrails active`.

- [ ] **Step 5: Run the layout test**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/layout.test.tsx
```

Expected: PASS.

### Task 5: Add Metadata And Public-Copy Guardrails

**Files:**
- Modify: `frontend/tests/guides.test.ts`
- Modify: `frontend/tests/seo.test.ts`
- Test: `frontend/tests/public-seo-copy.test.tsx`

- [ ] **Step 1: Add metadata quality assertions**

For every guide, assert:

```ts
expect(guide.metaTitle.length).toBeGreaterThanOrEqual(25);
expect(guide.metaTitle.length).toBeLessThanOrEqual(65);
expect(guide.metaDescription.length).toBeGreaterThanOrEqual(90);
expect(guide.metaDescription.length).toBeLessThanOrEqual(160);
expect(guide.metaDescription).not.toMatch(/best|ultimate|guarantee|revolutionary/i);
```

Also assert guide meta titles and descriptions are unique.

- [ ] **Step 2: Add homepage promise assertions**

Read `frontend/pages/index.tsx` in the test and assert that it contains the approved source-backed description and does not contain:

```text
Search-demand-tested
Validated demand pages
Prioritized by real demand
```

- [ ] **Step 3: Run focused tests**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend -- tests/guides.test.ts tests/seo.test.ts tests/public-seo-copy.test.tsx
```

Expected: PASS. If an existing description violates an objective length boundary, edit only that guide's `metaDescription` so the visible page supports the revised promise.

### Task 6: Run Full Quality Gates

**Files:**
- Verify all modified files
- Verify: `frontend/tests/*`
- Verify: `backend/tests/*`

- [ ] **Step 1: Run the spelling audit**

Run:

```bash
python3 /Users/kyen/.codex/skills/kyenai-seo-autopilot/scripts/audit_terms.py \
  --root /Users/kyen/Documents/SEO
```

Expected: `No high-confidence brand spelling issues found.`

- [ ] **Step 2: Run the secret scan**

Run searches that report filenames only and exclude local secret/environment locations:

```bash
rg -l \
  -g '!secrets/**' \
  -g '!.env.local' \
  -g '!frontend/node_modules/**' \
  -g '!frontend/.next*/**' \
  'ya29\\.|1//[A-Za-z0-9_-]{20,}|BEGIN (RSA |OPENSSH )?PRIVATE KEY|client_secret' .
```

Expected: no unexpected source or test files. Documentation that names `client_secret` generically is reviewed manually and is not treated as a leaked value.

- [ ] **Step 3: Run all frontend tests**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm test --prefix frontend
```

Expected: all Vitest files and tests pass with exit code 0.

- [ ] **Step 4: Run all backend tests**

Run:

```bash
python3 -m pytest backend/tests -q
```

Expected: all Pytest tests pass with exit code 0.

- [ ] **Step 5: Run the production frontend build**

Run:

```bash
source "$HOME/.nvm/nvm.sh"
nvm use 22.22.1
npm run build --prefix frontend
```

Expected: Next.js build exits 0 and lists the existing static/ISR routes without an unexpected new indexable page.

- [ ] **Step 6: Check route and SEO invariants**

Run:

```bash
rg -n "Primary keyword|GSC query watchlist|Attackability|KyenAI fit|Validated demand pages|search-demand-tested|SEO cluster" \
  frontend/pages frontend/components
python3 - <<'PY'
from pathlib import Path
text = Path("frontend/lib/seo.ts").read_text()
assert "What is the answer to" not in text
assert "What changed in ${article.title}" not in text
print("Public SEO wording invariants passed")
PY
```

Expected: the ripgrep command has no matches and the Python invariant check prints its pass message.

### Task 7: Deploy And Verify Production

**Files:**
- Deploy source tree to `/opt/seo/app`
- Preserve: `/opt/seo/app/.env.production`
- Preserve: `/opt/seo/secrets/*`

- [ ] **Step 1: Verify secure SSH access**

Run a non-interactive SSH probe using an existing SSH key or agent:

```bash
ssh -o BatchMode=yes -o ConnectTimeout=10 root@8.221.121.20 'printf ready'
```

Expected: `ready`. If key access is unavailable, use only an approved temporary interactive session; never place the password in source, a script, command history, or the plan.

- [ ] **Step 2: Synchronize the verified source**

Use `rsync` without delete semantics and exclude:

```text
.env.local
.env.production
node_modules
.next
.next-build
__pycache__
artifacts
secrets
client_secret_*.json
*.apps.googleusercontent.com.json
```

Destination:

```text
root@8.221.121.20:/opt/seo/app/
```

- [ ] **Step 3: Rebuild the production stack**

Run remotely:

```bash
cd /opt/seo/app
docker compose --env-file .env.production -f docker-compose.prod.yml up -d --build
docker compose --env-file .env.production -f docker-compose.prod.yml ps
```

Expected: build exits 0 and all services are running without restart loops.

- [ ] **Step 4: Verify public statuses**

Check:

```text
https://www.kyenai.com/
https://www.kyenai.com/guides
https://www.kyenai.com/guides/codex-vs-claude-code
https://www.kyenai.com/guides/secure-mcp-servers-ai-coding-agents
https://www.kyenai.com/articles/openai-codex-plugins-sites-annotations
https://www.kyenai.com/robots.txt
https://www.kyenai.com/sitemap.xml
https://api.kyenai.com/api/articles
```

Expected: public pages, robots, sitemap, and API return 200.

- [ ] **Step 5: Verify production SSR semantics**

Fetch sampled guide HTML and assert it contains:

```text
<title>
meta name="description"
rel="canonical"
<h1
Quick Answer
Evidence sources
application/ld+json
```

Assert it does not contain:

```text
Primary keyword
GSC query watchlist
Attackability
KyenAI fit
Validated demand pages
What is the answer to
```

Also count `Quick Answer` headings in the sampled guide and require exactly one visible heading.

- [ ] **Step 6: Verify sitemap stability**

Count production sitemap `<loc>` entries.

Expected: 33 entries unless an independently verified pre-existing production change altered the inventory. No `/operations`, `/api/`, tag parameter, localhost, or non-canonical URL may appear.

- [ ] **Step 7: Verify production container state and logs**

Run:

```bash
cd /opt/seo/app
docker compose --env-file .env.production -f docker-compose.prod.yml ps
docker compose --env-file .env.production -f docker-compose.prod.yml logs --tail=80 frontend backend caddy
```

Expected: services remain running; no build crash, restart loop, unhandled request exception, or secret value appears.

- [ ] **Step 8: Record deployment evidence**

Record:

- tests and counts;
- build result;
- changed public URLs;
- production status codes;
- sitemap count;
- container state;
- any unavailable external measurement such as GSC or PageSpeed quota.

Do not claim CTR or ranking improvement until post-recrawl data exists.
