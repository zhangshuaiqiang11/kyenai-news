# KyenAI Existing-Page SEO Optimization Design

## Goal

Improve the probability of stronger search presentation, click-through rate, rankings, and AI-answer citation for the existing KyenAI pages without adding new indexable URLs in this release.

The release must preserve existing slugs, canonical URLs, publication dates, and evidence boundaries. It must not claim guaranteed rankings or use invented experience.

## Current Evidence

- The production homepage and sampled guide/article pages return HTTP 200.
- Core content, metadata, canonical links, and JSON-LD are present in server-rendered HTML.
- `robots.txt` allows major search and AI crawlers while excluding operations and API routes.
- The sitemap currently contains 33 canonical routes with evidence-based `lastmod` values.
- Public search results already show KyenAI pages.
- Reliable GSC query/page rows are not currently available to this local run.
- The public guide template exposes internal editorial fields such as primary keyword, demand score, attackability score, fit score, and GSC query watchlist.
- Guide pages repeat the quick answer and generate template-like FAQ questions.
- The global status strip contains a hard-coded latest-update timestamp.
- The brand spelling audit reports no high-confidence errors.

## Strategy

Treat the site as an early indexed project between Gefei SEO stages S2 and S3. Improve the quality and clarity of already-indexed pages before creating more URLs.

The main hypothesis is:

1. Cleaner public pages reduce template and scaled-content signals.
2. User-facing titles, summaries, answers, and FAQs improve snippet relevance and click expectation.
3. Stronger contextual internal links and evidence presentation improve topical understanding and crawl paths.
4. Accurate dates and visible editorial boundaries improve trust.

## Public Guide Template

Remove public presentation of internal planning data:

- priority labels such as P0/P1/P2;
- demand, attackability, and KyenAI-fit scores;
- primary keyword labels;
- GSC query watchlists;
- internal-link planning language such as "SEO cluster."

Keep these fields in the content model for private editorial logic and tests. They must not appear in user-facing HTML.

Replace the removed material with reader-facing information:

- who the guide is for;
- what decision or task it helps complete;
- verified update date;
- evidence sources;
- related reading with natural explanations.

Render the first quick-answer section once. The answer panel becomes the single visible quick answer, and the same section is omitted from the later section loop.

## Guide Index And Homepage

Replace internal scoring and production language with reader-facing labels:

- guide cards show page type and a concise use case;
- homepage guide copy describes practical playbooks, not "validated demand pages";
- remove claims such as "search-demand-tested" when no reliable search dataset is available;
- use neutral language about evidence and editorial review.

No new navigation route or indexable page is added.

## FAQ Quality

Replace generated questions such as "What is the answer to [keyword]?" with natural questions derived from page intent:

- what the reader should do first;
- who the workflow fits;
- what evidence or limitations apply.

FAQ answers must be visible on the page and identical in meaning to the FAQPage JSON-LD. If a useful natural FAQ cannot be produced from existing facts, omit FAQ schema rather than create filler.

Article FAQs should use concise natural wording and must not repeat a title mechanically.

## Search Snippets

Review existing guide title and description values for:

- clear intent;
- concrete benefit;
- accurate scope;
- natural English;
- no unsupported superlatives;
- no repetitive site-wide formula.

Metadata changes are allowed only when the visible page fulfills the promise. Existing canonical URLs remain unchanged.

## Trust And Freshness

Replace the hard-coded global latest-update timestamp with a value derived from the newest real article or guide update available at build time.

Do not change article publication or modification dates unless the underlying article receives a substantive evidence-backed edit.

Keep visible authorship, source lists, editorial policy, entity disclosures, and citations. Do not imply endorsement by mentioned brands.

## Internal Links

Keep existing guide-to-guide and guide-to-article relationships, but rewrite public headings and explanations for readers.

Each guide should retain:

- links to at least two relevant guide pages where configured;
- links to relevant evidence updates where configured;
- a crawlable parent link to the guide index;
- descriptive anchor text.

No exact-match anchor stuffing or unrelated footer links will be added.

## Technical Boundaries

Preserve:

- SSR/SSG-visible core content;
- canonical URLs;
- sitemap membership and truthful `lastmod`;
- robots rules;
- Article, TechArticle, Breadcrumb, ItemList, Organization, and FAQ schema where valid;
- existing 404 and fallback behavior.

Do not expose private credentials, operations routes, API secrets, scoring data, or internal automation controls.

## Tests

Add or update tests proving:

- internal editorial fields are absent from rendered guide pages and guide cards;
- quick answers render once;
- FAQ questions are natural and schema matches visible answers;
- homepage and guide index avoid unsupported demand-validation language;
- the status date is derived from content rather than hard-coded;
- canonical, metadata, schema, sitemap, robots, and internal-link tests still pass;
- spelling and secret audits pass.

Run the full frontend and backend test suites and a production frontend build.

## Deployment

Deploy only after all quality gates pass.

Synchronize code without overwriting production environment files or secret mounts. Rebuild the production Docker Compose stack and verify:

- containers are running;
- homepage, guide index, sampled guides, sampled articles, robots, sitemap, and API return expected statuses;
- sampled SSR HTML contains the intended title, description, canonical, H1, visible answer, citations, and JSON-LD;
- sampled SSR HTML does not contain internal keyword/scoring/watchlist labels;
- sitemap route count does not unexpectedly expand;
- no secret or operations content is exposed.

## Success Criteria

This release is complete when:

1. Existing public URLs remain stable.
2. Internal SEO planning fields are no longer visible in production HTML.
3. Duplicate quick answers and template-like FAQs are removed.
4. Reader-facing descriptions, dates, evidence, and internal links remain complete.
5. Tests, production build, spelling audit, and secret audit pass.
6. The production deployment is healthy and the changed behavior is verified online.

Search ranking and CTR improvement remain outcomes to measure after recrawl; they are not guaranteed by deployment.
