# KyenAI Instruction Resource And MCP P0 Design

## Goal

Turn KyenAI's strongest early search signal into a reusable, evidence-backed resource system.

This release will:

- deeply update the existing AGENTS.md comparison guide;
- explain which instruction files each supported tool reads;
- document file priority, nesting, and scope;
- answer whether GitHub Copilot reads `CLAUDE.md`;
- provide copyable and downloadable instruction templates;
- show a real example repository tree;
- document Cursor legacy and current rule formats;
- define and render a same-repository benchmark protocol;
- publish only genuinely measured benchmark results;
- improve the MCP security guide;
- add contextual internal links from the homepage, guide index, and related guides;
- prepare a GitHub-ready compatibility and template asset package;
- make the same structure reusable in future KyenAI comparison projects.

Existing guide slugs and canonical URLs remain stable.

## Current Diagnosis

KyenAI is in the early S3 stage: Google Search Console has query, impression, and click data, but the sample is not stable.

The main P0 problems are:

1. High positions mostly come from brand queries or extremely low-volume long-tail queries.
2. Broader terms such as `codex vs claude code` and MCP security queries rank much lower.
3. The AGENTS.md comparison cluster has the strongest non-brand opportunity but does not yet answer all observed query variants.
4. The current comparison guide summarizes the file types but lacks a verifiable compatibility matrix, detailed scope rules, current Cursor migration guidance, downloadable examples, and a reproducible benchmark.
5. The MCP security guide has useful principles but needs stronger keyword alignment and operational depth around permissions, authentication, secret handling, write controls, logging, and deployment review.
6. Internal links exist, but the priority cluster needs clearer contextual paths from high-discovery pages and adjacent guides.
7. Google Search Console currently reports no external links. A useful public compatibility and template asset can become a linkable reference, but no link outcome is guaranteed.
8. Benchmark success rate, elapsed time, cost, and intervention counts must never be estimated or invented.

## Chosen Architecture

Use a structured resource system rather than hard-coding all new material inside one guide.

One typed source of truth will drive:

- the AGENTS.md comparison guide;
- reusable comparison components;
- downloadable Markdown templates;
- compatibility CSV and JSON exports;
- benchmark protocol and measured results;
- tests that prevent website and download drift;
- a GitHub-ready public asset package.

The site will not create a separate set of indexable resource pages in this release. The existing guide remains the primary search page, avoiding premature page expansion and keyword cannibalization.

## Resource Data Model

### Tool Instruction Support

Each compatibility record contains:

- tool and product name;
- recognized filename or path;
- support status: documented, legacy, observed, unsupported, or unknown;
- repository, nested-directory, path-specific, organization, or user scope;
- priority or conflict behavior when documented;
- nesting behavior;
- legacy or current status;
- concise practical guidance;
- official evidence URL;
- evidence publisher;
- verification date.

No support claim is rendered without a source or an explicit `unknown` status.

### Instruction Template

Each template contains:

- stable ID;
- target filename;
- title and purpose;
- applicable tools;
- copyable Markdown body;
- downloadable filename;
- cautions and safe-edit notes;
- source or rationale.

Initial templates:

- `AGENTS.md`;
- `CLAUDE.md`;
- `.github/copilot-instructions.md`;
- `.cursor/rules/project-guidance.mdc`.

### Benchmark Run

Each benchmark record contains:

- benchmark ID and task ID;
- public repository and exact revision;
- environment and date;
- tool and version;
- shared prompt and permitted file scope;
- success criteria and verification command;
- completion result;
- elapsed time;
- measured cost when available;
- human intervention count;
- changed-file count;
- evidence or run-note link;
- limitations.

Missing metrics render as `Not measured`. They are never replaced with estimates, sample values, or inferred values.

## AGENTS.md Comparison Guide

The guide keeps the existing editorial visual system and gains the following reading flow.

### Header And Direct Answer

The title remains focused on:

`AGENTS.md vs CLAUDE.md vs Cursor Rules vs Copilot Instructions`

The first answer block directly states:

GitHub Copilot support for `CLAUDE.md` depends on the Copilot surface. GitHub documents it as an agent-instruction option on selected surfaces, while support is absent on others. For the broadest repository-wide compatibility, use `.github/copilot-instructions.md`; use `CLAUDE.md` only where the current support matrix explicitly lists it.

The wording must remain tied to current official documentation and its verification date.

### Tool Compatibility Matrix

The matrix answers:

- which tool reads which file;
- whether support is documented or legacy;
- where the file applies;
- whether nested or path-specific rules are supported;
- what teams should use today;
- where the evidence comes from.

The first supported tool set is:

- OpenAI Codex;
- Anthropic Claude Code;
- GitHub Copilot;
- Cursor.

### File Priority And Scope

Explain:

- repository root rules;
- nested-directory rules;
- user-level and organization-level guidance where documented;
- path-specific rules;
- conflicts between shared and tool-specific files;
- the recommended canonical-source pattern.

The recommendation is to keep durable shared repository facts in one canonical source and use small tool-specific adapters when a tool requires a specific path.

### Cursor Legacy And Current Rules

Compare:

- legacy root `.cursorrules`;
- current project rules under `.cursor/rules/`;
- `.mdc` rule files;
- scope and migration guidance;
- compatibility cautions where behavior is version-dependent.

Do not imply that legacy behavior is current when official documentation says otherwise.

### Real Repository Tree

Show a directory diagram generated from the public example asset package, not a fabricated screenshot of an unrelated repository.

The diagram includes:

```text
example-repository/
├── AGENTS.md
├── CLAUDE.md
├── .github/
│   └── copilot-instructions.md
├── .cursor/
│   └── rules/
│       └── project-guidance.mdc
├── apps/
│   └── web/
│       └── AGENTS.md
└── packages/
    └── api/
```

It must be clearly labeled as the KyenAI public example repository layout.

### Copyable And Downloadable Templates

Each template is:

- visible as readable code;
- copyable from the page;
- available as a static download;
- generated from the same source record used by the page;
- tested to prevent empty files or filename drift.

### Same-Repository Benchmark

The page includes:

- the protocol;
- the public repository revision;
- the exact task;
- success criteria;
- environment;
- results table.

Result columns:

- tool and version;
- success;
- elapsed time;
- measured cost;
- human interventions;
- files changed;
- verification outcome;
- limitations.

Until a run is completed, the row displays `Not measured`. The page must not imply that an unmeasured tool performed better or worse.

### Recommended Migration Pattern

Give a practical sequence:

1. inventory current instruction files;
2. choose a canonical shared policy source;
3. add short tool-specific adapters;
4. remove contradictory commands;
5. verify each tool against a contained repository task;
6. schedule rule-drift review.

## Reusable Components

Create focused components rather than adding all markup to the guide page:

- compatibility matrix;
- scope and priority notes;
- repository tree;
- template download cards;
- benchmark protocol and result table;
- resource download list.

Components accept typed records and remain usable by future comparison or security guides.

The generic guide renderer only shows these resources when a guide explicitly attaches them.

## MCP Security Guide

Retain the existing slug and refocus metadata and visible copy around natural queries:

- MCP security;
- MCP server security;
- MCP security checklist;
- how to secure an MCP server;
- MCP permissions;
- MCP authentication;
- AI agent tool security.

The revised reading flow is:

1. direct answer;
2. threat model;
3. server and tool inventory;
4. permission matrix;
5. authentication and secret handling;
6. read, write, delete, network, and production boundaries;
7. prompt-injection assumptions;
8. audit logging;
9. third-party and supply-chain review;
10. deployment checklist;
11. incident and revocation readiness;
12. downloadable MCP security review template.

The page must distinguish protocol capabilities from deployment-specific controls and avoid claiming that MCP itself guarantees security.

## Internal Linking

Add contextual links inside explanatory copy rather than a keyword-heavy footer.

Target placements:

1. homepage priority resource copy to the AGENTS.md comparison;
2. homepage security resource copy to MCP security;
3. Guides page introductory featured path to the AGENTS.md comparison;
4. Guides page security path to MCP security;
5. AGENTS.md template guide to the comparison guide;
6. comparison guide to the AGENTS.md template;
7. Codex vs Claude Code guide to the comparison guide;
8. Claude Code hooks/MCP guide to the comparison guide;
9. MCP security guide to the comparison guide;
10. agent governance guide to MCP security;
11. local vs cloud guide to MCP security where contextually relevant.

The final implementation should add at least five and preferably eight to eleven useful contextual placements without repeating exact-match anchors mechanically.

## GitHub Asset Package

Prepare a standalone public package with:

```text
kyenai-agent-instruction-files/
├── README.md
├── LICENSE
├── templates/
│   ├── AGENTS.md
│   ├── CLAUDE.md
│   ├── copilot-instructions.md
│   └── cursor-project-rule.mdc
├── data/
│   ├── compatibility.json
│   └── compatibility.csv
├── example-repository/
│   ├── AGENTS.md
│   ├── CLAUDE.md
│   ├── .github/
│   │   └── copilot-instructions.md
│   └── .cursor/
│       └── rules/
│           └── project-guidance.mdc
└── benchmark/
    ├── protocol.md
    ├── results.json
    └── runs/
```

The README includes:

- a concise compatibility summary;
- the Copilot/`CLAUDE.md` direct answer;
- template usage;
- evidence and update policy;
- measured-only benchmark policy;
- a link to the KyenAI comparison guide.

The current project directory is not a Git repository, and the GitHub CLI is unavailable. The package will first be generated and validated locally. Publishing a new public repository through the connected GitHub account is an external write action and requires a clearly identified repository target and action-time confirmation.

## SEO And GEO Requirements

- Preserve canonical URLs.
- Keep primary answers in server-rendered HTML.
- Use descriptive headings and accessible tables.
- Keep visible content and structured data consistent.
- Cite official sources next to compatibility claims.
- Include explicit verification dates.
- Avoid unsupported superlatives and ranking claims.
- Do not create extra indexable pages solely to repeat the same intent.
- Keep downloadable assets linked from the primary guide.
- Update `dateModified` only when the substantive page update ships.

## Error Handling And Evidence Boundaries

- Unknown behavior renders as unknown, not inferred support.
- A broken download causes tests to fail.
- Missing benchmark values render as `Not measured`.
- Missing sources prevent a compatibility row from being marked documented.
- Export generation must escape CSV and JSON correctly.
- External GitHub URLs are not added until the repository exists.
- If the GitHub repository cannot be published, the site may expose local static downloads but must not claim a GitHub asset exists.

## Testing

Add tests that prove:

- the Copilot direct answer is present and unambiguous;
- every documented compatibility record has an official source and verification date;
- compatibility exports match website records;
- all four templates exist, contain expected headings, and download under correct filenames;
- the repository tree matches the public example package;
- Cursor legacy and current rule formats are distinguished;
- unmeasured benchmark fields render as `Not measured`;
- benchmark results cannot contain estimates;
- MCP security headings and keyword-aligned metadata are present;
- the priority internal links exist in rendered pages;
- existing canonical, sitemap, robots, schema, metadata, and public-copy tests continue to pass.

Run:

- focused frontend tests;
- full frontend tests;
- backend tests;
- production frontend build;
- brand spelling audit;
- secret audit;
- browser checks on desktop and mobile.

## Deployment And Verification

After tests pass:

1. deploy using the existing production process;
2. verify the homepage, Guides page, AGENTS.md comparison, AGENTS.md template, MCP security guide, robots, and sitemap;
3. inspect server-rendered titles, descriptions, H1, canonical links, resource sections, downloads, sources, and JSON-LD;
4. verify downloads return 200 and exact expected content types;
5. verify no internal scoring fields or secrets are exposed;
6. verify GitHub links only after the public repository exists;
7. record the deployment date for later GSC comparison.

## Success Criteria

The release is complete when:

1. The existing AGENTS.md comparison URL contains the approved information architecture.
2. Tool/file compatibility, scope, priority, Cursor migration, templates, repository tree, and benchmark protocol are driven by reusable typed records.
3. The Copilot/`CLAUDE.md` question receives a direct sourced answer.
4. All requested templates are copyable and downloadable.
5. Benchmark metrics are either verified measurements or explicitly `Not measured`.
6. The MCP security page has the approved operational structure and natural keyword coverage.
7. At least five contextual priority links are added, with a target of eight to eleven.
8. The GitHub-ready asset package is generated and validated.
9. The public GitHub asset is created only after the repository target is confirmed and the write action is approved.
10. Tests, build, audits, and browser verification pass.
11. Production output is verified after deployment.

Search ranking, impressions, backlinks, and citations remain measured outcomes rather than guaranteed completion criteria.
